---
name: General
about: Bugs, enhancements, documentation, tasks.
title: ''
labels: ''
assignees: ''

---

<!--

Have you considered asking for help on stackoverflow.com?

** Bug Reports **
Please submit issues against OSS supported versions, see https://spring.io/projects/spring-framework#support
Please provide a minimal sample application that reproduces the problem for faster issue triage.

** Enhancements requests **
Before explaining how you would like things to work,
please describe a concrete use case for this feature and how you have tried to solve this so far.

-->

